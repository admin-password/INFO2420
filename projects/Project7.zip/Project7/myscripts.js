/* No <script> tags in an external file. */

var logoNormal = new Image();
logoNormal.src = "Images/logo1.jpg";
var logoHover = new Image();
logoHover.src = "Images/logo2.jpg";

function rollover(isOver) {
    document.getElementById("logo").src = isOver ? logoHover.src : logoNormal.src;
}

var imgArray = [
    "image1lg.jpg",
    "image2lg.jpg",
    "image3lg.jpg",
    "image4lg.jpg"
];
var titleArray = [
    "Angry Fuzzy Cat",
    "Cat and Dog",
    "Parrot and Dog",
    "Two Hunting Dogs"
];
var imagePath = "Images/Fullsize/";

function swapImage(index) {
    document.getElementById("bigImage").src = imagePath + imgArray[index];
    document.getElementById("bottomText").innerHTML = titleArray[index];
}

function preloadImages() {
    var cache = [];
    for (var i = 0; i < imgArray.length; i++) {
        cache[i] = new Image();
        cache[i].src = imagePath + imgArray[i];
    }
}
